"""Core economic modelling package."""


