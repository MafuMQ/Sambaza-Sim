"""Core economic modelling package."""
